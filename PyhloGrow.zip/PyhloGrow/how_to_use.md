# How to Use – Accurate Height Predictor

This document explains **how to correctly use the application** to obtain the most scientifically meaningful results.

The tool is designed for **accuracy and honesty**, not speed or entertainment. Please read carefully.

---

## 1. Eligibility Check

Before using the application:

- ✅ You must be **12 years old or older**
- ❌ If you are under 12, results will not be generated due to high biological variability

This restriction is intentional and science-based.

---

## 2. Measuring Your Height Correctly

Accurate input = accurate output.

### Recommended method:
1. Stand barefoot on a flat surface
2. Keep your back, shoulders, and head against a wall
3. Look straight forward (Frankfurt plane)
4. Measure **in the morning if possible**
5. Record height in **centimeters (cm)**

> Height can vary 1–2 cm between morning and evening.

---

## 3. Required Inputs (What You Will Be Asked)

The application will guide you through several scientific sections.

### A. Basic Data
- Sex
- Date of birth
- Current height and weight

These are mandatory for all users.

---

### B. Genetics

You will be asked about:
- Father’s height
- Mother’s height
- Heights of siblings (if any)
- Tallest and shortest known adult relatives

> If you do not know an exact value, give your **best realistic estimate**.

Genetic data strongly influences the final range.

---

### C. Population Reference

Select the population group that best represents your genetic background.

This does **not** lock your height to an average value. It only:
- Adjusts growth distributions
- Improves percentile interpretation
- Reduces systematic bias

---

### D. Growth History (Objective)

Instead of asking subjective questions, the app uses real data:

- Your height now
- Your height approximately 12 months ago
- Your height approximately 24 months ago

The app will automatically:
- Calculate growth velocity
- Detect acceleration or slowing
- Estimate your current growth phase

If older measurements are unavailable, the confidence level will be reduced.

---

### E. Puberty & Maturity Indicators

You will see simple, non-medical questions such as:

- Has your voice changed?
- Facial or body hair development
- Menstrual history (for females)

Choose the option that best matches your current state.

These inputs help estimate **biological maturity**, not appearance.

---

### F. Lifestyle Factors

You may be asked about:
- Average sleep duration
- Nutrition quality
- Physical activity
- Past illness or long-term stress

These factors **do not magically increase height**, but they influence:
- Remaining growth potential
- Confidence of the estimate

---

## 4. Understanding the Results

After completing all sections, you will receive:

- **Minimum expected adult height**
- **Most probable adult height**
- **Maximum expected adult height**
- **Estimated remaining growth (cm)**
- **Confidence level**
- **Margin of error**

### Important:
- This is a **statistical range**, not a promise
- Wider ranges mean higher uncertainty
- Confidence improves with better data quality

---

## 5. How to Improve Accuracy

To get the best possible result:

- Measure height carefully
- Provide family heights when possible
- Use real past measurements
- Answer puberty questions honestly

Missing or uncertain data will not break the model, but it will lower confidence.

---

## 6. Limitations (Read This)

This application:

- Cannot replace medical assessment
- Cannot account for rare growth disorders
- Cannot predict effects of future illness or trauma

For clinical decisions, consult a healthcare professional.

---

## 7. Data Privacy

- No data is stored
- No data is transmitted
- All calculations run locally in your browser

---

## 8. Final Note

This tool prioritizes **scientific honesty over false precision**.

If you want guaranteed answers, such tools do not exist without medical imaging.

If you want the **most accurate non-clinical estimate possible**, you are using the right one.