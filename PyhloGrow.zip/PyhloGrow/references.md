# References

This document lists **scientific literature, datasets, and established frameworks** that inform the design and validation of the Accurate Height Predictor.

The project does not copy proprietary models or datasets. Instead, it aligns conceptually and methodologically with **public, peer-reviewed growth science**.

---

## 1. Human Growth & Puberty

1. Tanner, J. M. (1962). *Growth at Adolescence*. Blackwell Scientific Publications.  
   — Foundational work on pubertal stages, growth timing, and peak height velocity.

2. Karlberg, J. (1987). *On the modeling of human growth*. Statistics in Medicine.  
   — Mathematical modeling of longitudinal growth patterns.

3. Rogol, A. D., Roemmich, J. N., & Clark, P. A. (2002). *Growth at puberty*. Journal of Adolescent Health.  
   — Detailed analysis of pubertal growth dynamics and sex differences.

---

## 2. Growth Velocity & Peak Height Velocity (PHV)

4. Mirwald, R. L., Baxter-Jones, A. D. G., Bailey, D. A., & Beunen, G. P. (2002).  
   *An assessment of maturity from anthropometric measurements*. Medicine & Science in Sports & Exercise.  
   — Non-invasive estimation of biological maturity using growth data.

5. Malina, R. M., Bouchard, C., & Bar-Or, O. (2004). *Growth, Maturation, and Physical Activity*. Human Kinetics.

---

## 3. Genetics of Height

6. Visscher, P. M., et al. (2008). *Heritability in the genomics era*. Nature Reviews Genetics.  
   — Quantifies genetic contribution to human height.

7. Wood, A. R., et al. (2014). *Defining the role of common variation in the genomic and biological architecture of adult human height*. Nature Genetics.

8. Yang, J., et al. (2010). *Common SNPs explain a large proportion of the heritability for human height*. Nature Genetics.

---

## 4. Population & Global Growth Standards

9. World Health Organization (WHO).  
   *WHO Child Growth Standards*.  
   — International reference for growth patterns.

10. Centers for Disease Control and Prevention (CDC).  
    *CDC Growth Charts (United States)*.

11. Cole, T. J., & Green, P. J. (1992). *Smoothing reference centile curves*. Statistics in Medicine.  
    — Statistical methods used in growth percentile construction.

---

## 5. Bone Age & Maturity Estimation (Non-Imaging)

12. Greulich, W. W., & Pyle, S. I. (1959). *Radiographic Atlas of Skeletal Development of the Hand and Wrist*.  
    — Gold standard reference for bone age (used conceptually, not directly).

13. Beunen, G., & Malina, R. M. (1988). *Growth and physical performance relative to the timing of puberty*. Exercise and Sport Sciences Reviews.

---

## 6. Environmental & Lifestyle Factors

14. Silventoinen, K. (2003). *Determinants of variation in adult height*. Journal of Biosocial Science.  
    — Environmental influences on height outcomes.

15. Eveleth, P. B., & Tanner, J. M. (1990). *Worldwide Variation in Human Growth*. Cambridge University Press.

---

## 7. Methodological & Ethical References

16. Ioannidis, J. P. A. (2005). *Why most published research findings are false*. PLoS Medicine.  
    — Justifies conservative claims and uncertainty modeling.

17. American Academy of Pediatrics.  
    *Ethical considerations in pediatric growth assessment*.

---

## Notes on Use

- References are used to **justify methodology**, not to claim direct clinical equivalence.
- Growth charts and models are used conceptually; no proprietary datasets are redistributed.
- Citations reflect consensus science rather than experimental claims.

---

## Final Statement

This reference list exists to allow **independent verification** of the scientific principles underlying the project.

Any future changes to the model should be traceable to updated or additional peer-reviewed sources.

