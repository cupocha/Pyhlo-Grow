# Limitations – Accurate Height Predictor

This document describes the **known limitations and constraints** of the Accurate Height Predictor, ensuring **scientific honesty, transparency, and user awareness**.

---

## 1. Age Restrictions

- The model is designed for users aged **12 years and older**.
- For children under 12, growth variability is too high for reliable estimates.
- Adolescents in early puberty may have **wider confidence intervals** due to rapid, unpredictable growth.

---

## 2. Non-Clinical Nature

- This tool **does not replace medical assessment**.
- It is **not diagnostic** and cannot identify growth disorders or hormonal deficiencies.
- Bone age estimation is a **statistical proxy**, not based on radiography.

---

## 3. Input Quality Dependence

- Accuracy depends on **precise height measurements**.
- Historical height data improves growth velocity calculations; missing or inaccurate data reduces confidence.
- Family height inputs should be as accurate as possible; estimates may reduce predictive reliability.

---

## 4. Environmental and Lifestyle Factors

- Sleep, nutrition, activity, and illness are incorporated **as modifiers for confidence**, not as determinants of height.
- The model cannot predict effects of sudden illness, trauma, or extreme environmental changes.

---

## 5. Genetic & Population Considerations

- Extended family inputs provide a statistical envelope, but rare genetic conditions or mutations are **not captured**.
- Population/continental adjustments **reflect statistical averages**, not individual certainty.
- Polygenic effects are approximated, not sequenced genetically.

---

## 6. Output Nature

- The model provides **ranges with confidence intervals** rather than single deterministic numbers.
- Wider ranges reflect **higher uncertainty** due to age, missing data, or inconsistent inputs.
- Confidence levels are internally derived; they do not guarantee precision.

---

## 7. Data Privacy & Storage

- All calculations are performed locally in the browser.
- No user data is stored, transmitted, or analyzed externally.
- Predictive output is **ephemeral** and entirely based on user input.

---

## 8. Ethical Boundaries

- No pseudo-science, astrology, or personality correlations are used.
- The app **cannot be used for commercial predictions, competitions, or performance evaluation**.
- Users are explicitly informed of uncertainty and statistical nature of predictions.

---

## 9. Technical Constraints

- Only deterministic HTML/CSS/JavaScript is used; no machine learning or external datasets are incorporated.
- All formulas are documented; reproducibility is guaranteed for the same inputs.

---

## 10. Summary

This section exists to **manage expectations** and **reinforce scientific credibility**. Users should understand that:
- The tool provides an **estimate, not a promise**
- Uncertainty is inherent to human growth
- Best results come from **accurate inputs and honest reporting**

Acknowledging these limitations is central to the project’s **ethical and scientific integrity**.

