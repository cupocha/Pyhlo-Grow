# Scientific Model Documentation – Accurate Height Predictor

This document details the **scientific and mathematical foundations** of the Accurate Height Predictor. It is intended for developers, researchers, and technically literate users who want to understand exactly how predictions are calculated.

All methods are deterministic, evidence-based, and designed to maximize accuracy while maintaining transparency.

---

## 1. Overview of the Model

The model consists of four main components:

1. **Genetic Height Envelope**
2. **Growth Velocity Reconstruction**
3. **Biological Maturity Estimation**
4. **Confidence & Environmental Adjustments**

Each component contributes to a probabilistic adult height range rather than a single deterministic value.

---

## 2. Genetic Height Envelope

### Inputs:
- Father’s height (H_f)
- Mother’s height (H_m)
- Sibling heights (H_s, optional)
- Tallest & shortest known adult relatives (H_max, H_min)
- Population reference group (for variance adjustment)

### Calculation:
1. Mid-parental height (MPH):
   - Males: `MPH = (H_f + H_m + 13) / 2`
   - Females: `MPH = (H_f + H_m - 13) / 2`

2. Extended family bounds:
   - Compute genetic envelope using: `H_env = [max(H_min, MPH - σ_ext), min(H_max, MPH + σ_ext)]`
   - σ_ext = standard deviation derived from extended family variance (~3–6 cm)

3. Population adjustment:
   - Apply ±σ_pop depending on continental growth reference
   - σ_pop reflects average population standard deviation from WHO/CDC data

**Output:** Probabilistic adult height range (baseline)

---

## 3. Growth Velocity Reconstruction

### Inputs:
- Current height (H_now)
- Height 12 months ago (H_12mo)
- Height 24 months ago (H_24mo)

### Calculations:
1. Annual growth velocity:
   - `V_1 = H_now - H_12mo`
   - `V_2 = H_12mo - H_24mo`

2. Acceleration/Deceleration:
   - `A = V_1 - V_2`
   - Positive A → growth spurt, Negative A → slowing growth

3. Phase estimation:
   - Compare V_1 and V_2 to age- and sex-specific percentiles
   - Classify as Pre-PHV, PHV, or Post-PHV

**Output:** Adjusted predicted remaining growth based on velocity phase

---

## 4. Biological Maturity Estimation

### Inputs:
- Puberty markers (voice change, menarche, body hair, shoulder/hip widening)
- Sex and chronological age

### Method:
1. Map qualitative markers to **numerical maturity scores** (0–3 scale)
2. Combine with growth phase to estimate **biological age offset**
3. Adjust predicted adult height range accordingly

**Note:** This is a **statistical proxy**, not an imaging-based bone age

---

## 5. Confidence & Environmental Adjustments

### Inputs:
- Sleep quality and duration
- Nutrition quality
- Physical activity level
- History of chronic illness or stress

### Method:
- Environmental factors modify **confidence interval width**, not mean prediction
- Poor environmental scores → wider range, lower confidence
- Good scores → slightly narrower range, higher confidence

**Output:** Probabilistic height range with confidence annotation

---

## 6. Final Output Construction

1. Merge genetic envelope, growth velocity, and maturity estimates
2. Apply environmental modifiers to confidence
3. Output:
   - Minimum expected height
   - Most probable height
   - Maximum expected height
   - Remaining growth estimate
   - Confidence level (High / Moderate / Low)

All outputs are **ranges with margins of error** to reflect biological uncertainty.

---

## 7. Deterministic Properties

- Every calculation is deterministic: same input → same output
- No machine learning or probabilistic sampling is used
- Formulas are **fully documented and transparent**

---

## 8. Ethical & Practical Considerations

- Only used for individuals aged 12+
- Results are for educational and research purposes, **not clinical decisions**
- Encourages honest input to maximize predictive validity

