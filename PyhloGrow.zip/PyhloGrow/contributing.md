# Contributing Guidelines

Thank you for your interest in contributing to **Accurate Height Predictor**.

This project is **science-first**. Contributions are welcome **only if they preserve or improve scientific validity**. This is not a generic web app or a feature-driven product.

---

## Core Rule (Non-Negotiable)

> **Scientific integrity has absolute priority over features, popularity, or convenience.**

Any contribution that weakens the scientific model, increases subjectivity, or introduces pseudo-science will be rejected.

---

## What Contributions Are Welcome

### 1. Scientific Improvements

You may contribute if you can:
- Improve statistical modeling of growth
- Reduce subjectivity in user inputs
- Refine population variance handling
- Improve confidence estimation logic
- Add peer-reviewed references

All scientific changes **must be justified**.

---

### 2. Code Quality Improvements

- Refactoring for clarity (no logic changes)
- Performance improvements (deterministic only)
- Accessibility improvements (WCAG-compliant)
- Better documentation and comments

No external APIs or tracking libraries are allowed.

---

### 3. UI / UX Improvements

UI changes are accepted **only if** they:
- Reduce eye strain
- Improve clarity and readability
- Preserve clinical / research-style presentation

Visual changes must not mislead users or imply certainty.

---

## What Contributions Are NOT Welcome

- ❌ Claims of "100% accuracy"
- ❌ Deterministic height outputs
- ❌ Astrology, personality traits, or non-biological factors
- ❌ Gamification or entertainment features
- ❌ Data collection, tracking, or analytics

---

## Contribution Requirements

All pull requests must include:

1. **Clear description** of the change
2. **Scientific justification** (if applicable)
3. **Before vs after explanation**
4. No breaking of existing ethical constraints

Unjustified changes will not be reviewed.

---

## Coding Standards

- HTML: semantic, accessible
- CSS: dark-mode-first, low-luminance design
- JavaScript: minimal, deterministic math only

All formulas must be commented and explainable.

---

## Review Process

- Every contribution is reviewed manually
- Scientific changes may require discussion
- Maintainers reserve the right to reject without merge

This protects the project’s credibility.

---

## Final Note

If your goal is to make the app **flashier**, this is not the right project.

If your goal is to make it **more scientifically honest and accurate**, your contribution is welcome.

