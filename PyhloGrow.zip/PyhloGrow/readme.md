# Accurate Height Predictor (Science-Based)

A **free, open-source, non-clinical human height prediction web application** designed to push the **upper scientific limit** of adult height estimation **without medical imaging or genetic testing**.

This project exists because the vast majority of so‑called "accurate height predictors" rely on pseudo‑science, oversimplified formulas, or entertainment logic. This application explicitly does **not**.

---

## Core Philosophy

- **Science over certainty** — results are probabilistic, not deterministic
- **Transparency over hype** — every variable has a documented role
- **Upper-bound accuracy** — within the limits of non-clinical data
- **Free and open** — no paywalls, no dark patterns, no data selling

If medical-grade accuracy is required, bone-age imaging or genetic testing is necessary. This project does not claim to replace clinical tools.

---

## What This Application Does

The application estimates **adult height ranges** for users aged **12 years and older** by combining:

- Core genetics (parental height)
- **Extended family genetics** (polygenic variance modeling)
- **Population / continental growth references**
- Objective growth velocity reconstruction
- Puberty-related biological maturity markers
- Environmental modifiers (sleep, nutrition, illness)

The output is a **scientifically justified height range** with confidence indicators — never a single absolute value.

---

## What This Application Does NOT Do

- ❌ It does not provide medical advice
- ❌ It does not output guaranteed or exact final height
- ❌ It does not use astrology, personality traits, or unsupported correlations
- ❌ It does not store, transmit, or sell user data

---

## Scientific Basis (High-Level)

Human height is influenced primarily by:

- **Genetics (~70–80%)**
- **Growth timing and biological maturity**
- **Environmental factors (~20–30%)**

This application models these factors using:

1. **Genetic Height Envelope**  
   Mid-parental height + extended family extremes + population variance

2. **Growth Kinetics Analysis**  
   Objective reconstruction of annual growth velocity

3. **Biological Maturity Estimation**  
   Puberty markers used as a statistical proxy for bone age

4. **Environmental Modifiers**  
   Used to adjust confidence and remaining growth estimates

All calculations are deterministic and documented in code comments.

---

## Output Structure

Each prediction includes:

- Minimum expected adult height
- Most probable adult height
- Maximum expected adult height
- Estimated remaining growth (cm)
- Confidence level (High / Moderate / Low)
- Explicit margin of error

This reflects real biological uncertainty instead of hiding it.

---

## Age Restrictions

- Results are **only generated for users aged 12+**
- Below this age, growth variability is too high for responsible estimation

---

## User Interface Design

- **Dark mode by default**
- Cyan‑blue accents on low‑luminance backgrounds
- Reduced retinal strain and perceived brightness
- Clinical / research‑style layout

The UI prioritizes **visual ergonomics**, not aesthetic trends.

---

## Technology Stack

- HTML (structure)
- CSS (dark-mode, accessibility-focused styling)
- Minimal JavaScript (deterministic mathematical calculations only)

No external APIs. No tracking. No analytics.

---

## Ethical & Legal Notice

This software:

- Provides **non-clinical estimates only**
- Does not replace professional medical evaluation
- Must not be used for diagnosis or treatment decisions

By using this software, you acknowledge these limitations.

---

## License

This project is released under the **MIT License**. See the `LICENSE` file for full details.

---

## Project Status

This project is under **active scientific iteration**. Improvements focus on:

- Reducing subjectivity further
- Refining population variance modeling
- Improving confidence estimation

Contributions are welcome **if and only if** they respect the scientific integrity of the project.

---

## Disclaimer (Plain Language)

This app gives an *educated statistical estimate*, not a promise. Human growth is complex, and no non-medical tool can predict it perfectly. This project chooses honesty over false precision.

